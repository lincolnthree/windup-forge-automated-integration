package ${package.name};

public interface ${service.name} {
    
    /**
     * This is an example in-only service operation.  You can use
     * this method as is or delete it and add your own.
     * @param content type expected in the message body
     */
    void process(String content);
    
}
